#include <wups.h>
#include <whb/log.h>
#include <whb/log_module.h>
#include <whb/log_cafe.h>
#include <whb/log_udp.h>
#include <string.h>

#include <coreinit/title.h>

#include <patcher/rplinfo.h>
#include <patcher/patcher.h>

WUPS_PLUGIN_NAME("GiveMiiYouTubeUniversal");
WUPS_PLUGIN_DESCRIPTION("Allows both the YouTube app and the YouTube Beta app to continue functioning after their discontinuation");
WUPS_PLUGIN_VERSION("v2.0u");
WUPS_PLUGIN_AUTHOR("GaryOderNichts and some other");
WUPS_PLUGIN_LICENSE("MIT");

#define YOUTUBE_CLIENT_ID "e921a604fce89365498613fdf001b492"

// Both known YouTube title IDs this plugin should patch
#define YOUTUBE_TITLE_ID      0x0005000010105700llu // regular YouTube app
#define YOUTUBE_BETA_TITLE_ID 0x000500001014CE00llu // YouTube Beta app (still on NUS)

#define YOUTUBE_USERAGENT_PLATFORM "WiiU; "
#define YOUTUBE_USERAGENT_PLATFORM_REPLACEMENT "NoU; "

ON_APPLICATION_START()
{
    uint64_t title_id = OSGetTitleID();

    // If this is neither YouTube app, no need to do anything
    if (title_id != YOUTUBE_TITLE_ID && title_id != YOUTUBE_BETA_TITLE_ID) {
        return;
    }

    // Init logging
    if (!WHBLogModuleInit()) {
        WHBLogCafeInit();
        WHBLogUdpInit();
    }

    WHBLogPrintf("GiveMiiYouTubeUniversal: applying patches...");

    // Patch the dynload functions so GetRPLInfo works
    if (!PatchDynLoadFunctions()) {
        WHBLogPrintf("GiveMiiYouTubeUniversal: Failed to patch dynload functions");
        return;
    }

    // Get the RPLInfo
    auto rpl_info = TryGetRPLInfo();
    if (!rpl_info) {
        WHBLogPrintf("GiveMiiYouTubeUniversal: Failed to get RPL info");
        return;
    }

    // Find the rpx
    rplinfo rpls = *rpl_info;
    auto lb_shell_rpx = FindRPL(rpls, "lb_shell.rpx");
    if (!lb_shell_rpx) {
        WHBLogPrintf("GiveMiiYouTubeUniversal: Failed to find lb_shell.rpx");
        return;
    }

    // Patch the useragent platform
    OSDynLoad_NotifyData rpx_data = *lb_shell_rpx;
    if (!replace_string(rpx_data.dataAddr, rpx_data.dataSize,
        YOUTUBE_USERAGENT_PLATFORM, sizeof(YOUTUBE_USERAGENT_PLATFORM),
        YOUTUBE_USERAGENT_PLATFORM_REPLACEMENT, sizeof(YOUTUBE_USERAGENT_PLATFORM_REPLACEMENT))) {
        WHBLogPrintf("GiveMiiYouTubeUniversal: Failed to replace useragent platform");
        return;
    }
}

DECL_FUNCTION(int, AcquireIndependentServiceToken__Q2_2nn3actFPcPCc, uint8_t* token, const char* client_id)
{
    // If this is the YouTube client, return sucess
    if (client_id && strcmp(client_id, YOUTUBE_CLIENT_ID) == 0) {
        WHBLogPrintf("GiveMiiYouTubeUniversal: Faking service sucess for '%s'", client_id);
        return 0;
    }

    return real_AcquireIndependentServiceToken__Q2_2nn3actFPcPCc(token, client_id);
}

WUPS_MUST_REPLACE(AcquireIndependentServiceToken__Q2_2nn3actFPcPCc, WUPS_LOADER_LIBRARY_NN_ACT, AcquireIndependentServiceToken__Q2_2nn3actFPcPCc);
