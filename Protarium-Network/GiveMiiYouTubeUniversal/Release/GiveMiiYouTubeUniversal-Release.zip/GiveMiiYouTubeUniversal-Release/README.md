# GiveMiiYouTubeUniversal

A merged/unified version of [GiveMiiYouTube](https://github.com/PretendoNetwork/GiveMiiYouTube) and
[GiveMiiYouTubeBeta](https://github.com/progameruser0400/GiveMiiYouTubeBeta) that works with **both**
the (discontinued) Wii U YouTube app and the Wii U YouTube Beta app (the last YouTube app still
available on the Nintendo Update Server) from a single Aroma plugin.

Since October 27, 2022 the YouTube app for the Wii U has been discontinued and the app can no longer
be accessed. To check if the service is available the YouTube app requests a service token from
`https://account.nintendo.net/v1/api/provider/service_token/` with a YouTube specific client id.
This endpoint now responds with:
```html
<errors>
    <error>
        <code>0123</code>
        <message>Service has expired</message>
    </error>
</errors>
```
The app then checks if acquiring this token has been sucessful and if not it will display the error.
The acquired token itself is not used. This is a Wii U Plugin System plugin for Aroma which just
makes this request always return sucess and thus allowing the YouTube apps to continue functioning.

## Info about version 2.0
On November 1st, 2022 YouTube started returning response 404 for the `WiiU` useragent platform.
Since v2.0 this plugin patches the platform in the useragent for the YouTube app to `NoU` instead
of `WiiU`, which bypasses this block.

## What changed in this "Universal" version
The two upstream plugins were functionally identical apart from four lines in `source/main.cpp`
(plugin metadata, and the hardcoded title ID they gate on). This version simply checks the running
title ID against **both** known title IDs instead of just one:

- `0x0005000010105700` — regular YouTube app
- `0x000500001014CE00` — YouTube Beta app

Everything else (the service-token spoof, the useragent patch, the RPL patcher) is untouched and
already worked for both apps since it isn't title-specific.

Note (carried over from the Beta app's README): on the Beta app, video only goes to the gamepad
because of how that app is built — this is a limitation of the app itself, not something this
plugin can fix.

## Special Thanks to
[@ashquarky](https://github.com/ashquarky) for the awesome patcher framework which was taken from
[Nimble](https://github.com/PretendoNetwork/Nimble), and to GaryOderNichts (original GiveMiiYouTube)
and progameruser0400 (GiveMiiYouTubeBeta) for the original plugins this was merged from.

## Building
```bash
# Build docker image (only needed once)
docker build . -t givemiiyoutube_universal_builder

# make
docker run -it --rm -v ${PWD}:/project givemiiyoutube_universal_builder make

# make clean
docker run -it --rm -v ${PWD}:/project givemiiyoutube_universal_builder make clean
```

## Installing
Copy the built `GiveMiiYouTubeUniversal.wps` to `sd:/wiiu/environments/aroma/plugins` on your SD card.
